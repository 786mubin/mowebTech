'use strict';
const express = require('express');
const cors = require('cors');
const getData = require('../functions/get');
const insertData = require('../functions/insert');
const mongoose = require('mongoose');
const fileUpload = require('express-fileupload');
const { deleteData } = require('../functions/delete');
const { searchData } = require('../functions/search');
const mongodbURL = "mongodb://localhost:27017/mowebTech"
mongoose.connect(mongodbURL)
const app = express();
app.use(express.json());
app.use(express.static('public')); //to access the files in public folder
//id , name , photo , dob, phonenumberm
app.use(fileUpload())
app.use(
    cors({
        origin: "http://localhost:3000"
    })
)


app.post('/getData', async (req, res) => {
    var data = await getData.getData();
    console.log("mydata  : ", data.length)
    res.send(data)
})

app.post('/insertData', async (req, res) => {
    console.log("insert")
    var { name, dob, phoneNumber, voucherType, voucherDate } = req.body;
    console.log("1")
    if (req.files) {
        console.log("2")

        const myFile = req.files.file;
        myFile.mv('public/images/' + myFile.name);
        var data = await insertData.insertData(myFile.name, name, dob, phoneNumber, voucherType, voucherDate);
        console.log("data inser : ", data)
        res.send(data);
    }
    else {
        res.json({ error: "Provide required fields" })
    }
})

app.post('/duplicateData', async (req, res) => {
    console.log(req.body);
    var { name, image, dob, phoneNumber, voucherType, voucherDate } = req.body;
    var data = await insertData.insertData(image, name, dob, phoneNumber, voucherType, voucherDate);
    res.send(data);
})

app.post('/deleteData', async (req, res) => {
    var { id } = req.body;
    console.log("id is : ", id)
    var data = await deleteData(id);
    res.send(data)

})

app.post('/searchData', async (req, res) => {
    console.log("req : ", req.body)
    var { input } = req.body;
    var data = await searchData(input);
    console.log("data out : ", data)
    res.send(data)
})
app.listen(4000, () => {
    console.log("server is running on 4000 port ")
})

