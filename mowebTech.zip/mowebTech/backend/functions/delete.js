const userModel = require('../userSchema/models');
const deleteData = async (id) => {
    try {
        if (id) {
            var data = await userModel.userModel.findOneAndRemove({ _id: id });
            return {success : "Record Deleted Successfull"}
        }
        else {
            return { error: "Provide Id" }
        }

    }
    catch (error) {
        console.log("delete data error : ", error);
        return { error: `${error}` }
    }
}


module.exports = { deleteData }