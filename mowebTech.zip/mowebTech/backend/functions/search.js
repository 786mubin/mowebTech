
const userModel = require('../userSchema/models');


const searchData = async (input) => {
    try {
        var data = await userModel.userModel.find({
            $or: [
                { name: { $regex: input } },
                { name: { $regex: input.toLowerCase() } },
                { name: { $regex: input.toUpperCase() } },
                { name: { $regex: input.charAt(0).toUpperCase() + input.slice(1) } },
            ]
        });

        return data
    }
    catch (error) {
        console.log("error search data : ", error)
        return { error: `${error}` }
    }
}

module.exports = { searchData }