
const userModel = require('../userSchema/models');

const insertData = async (image, name, dob, phoneNumber, voucherType, voucherDate) => {
    try {
        //id , name , photo , dob, phonenumberm
        if (image!=='', name!=='', dob!=='', phoneNumber!=='', voucherType!=='', voucherDate!=='') {
            var insertData = {
                name: name,
                image: image,
                dob: dob,
                phoneNumber: phoneNumber,
                voucherType: voucherType,
                voucherDate: voucherDate
            }
            await userModel.userModel.create(insertData);
            return {success : "Inserted Successful!"}
        }
        else {
            console.log("something is missing in getData fields");
            return { error: "provide required fields" }
        }
    }
    catch (error) {
        console.log("insertdata error : ", error);
        return { error: `${error}` }
    }
}

module.exports = { insertData };