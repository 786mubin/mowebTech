const userModel = require('../userSchema/models');
const getData = async () => {
    try {
        //id , name , photo , dob, phonenumberm

        // http://localhost:4000/images/ckt.PNG
        var data = await userModel.userModel.find();
        if (data.length) {
            return data;
        }
        else {
            return [];
        }

    }
    catch (error) {
        console.log("getdata error : ", error);
        return { error: `${error}` }
    }
}


module.exports = { getData }