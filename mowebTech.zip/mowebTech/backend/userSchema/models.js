const mongoose = require('mongoose');
const schema = mongoose.Schema;

//id , name , photo , dob, phonenumberm

const userSchema = schema({
    name: { type: String, default: null },
    image: { type: String, default: null },
    dob: { type: String, default: null },
    phoneNumber: { type: Number, default: null },
    voucherType: { type: String, default: null },
    voucherDate: { type: String, default: null },
})

const userTableName = "mowebUsers";

const userModel = mongoose.model(userTableName, userSchema, "mowebUsers");

module.exports = { userModel };