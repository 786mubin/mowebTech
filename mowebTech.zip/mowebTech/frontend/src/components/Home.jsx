import { useContext, useEffect, useState } from "react";
import { Moweb } from "../App";
import Message from "./Message";
import Table from "./Table";
const Home = () => {

    var { dataMsgs, submitData, getSearchData, getData } = useContext(Moweb);
    const [photo, setPhoto] = useState('');
    const [name, setName] = useState('');
    const [dob, setDob] = useState('');
    const [number, setNumber] = useState('');
    const [voucherType, setVoucherType] = useState('payment');
    const [voucherDate, setVoucherDate] = useState('');

    const [search, setSearch] = useState('');

    const clearStates = () => {
        setPhoto('');
        setName('');
        setDob('');
        setNumber('');
        setVoucherType('payment');
        setVoucherDate('');
    }

    useEffect(() => {
        getData();
    }, [])


    useEffect(() => {
        if (search !== '') {
            getSearchData(search)
        }
        else {
            getData();
        }
    }, [search])


    const thisSubmit = () => {
        submitData(photo, name, dob, number, voucherType, voucherDate);
        clearStates();
    }

    return (
        <>
            <Message />

            {/* <!-- Modal --> */}
            <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">Add New Voucher</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <p>Photo : <input type="file" onChange={(e) => setPhoto(e.target.files[0])} /></p>
                            <p>Name : <input type="text" value={name} onChange={e => setName(e.target.value)} /></p>
                            <p>DOB : <input type="date" value={dob} onChange={e => setDob(e.target.value)} /></p>
                            <p>phoneNumber : <input type="number" value={number} onChange={e => setNumber(e.target.value)} /></p>
                            <p> Voucher type : &nbsp;
                                <select value={voucherType} onChange={e => setVoucherType(e.target.value)}>
                                    <option value="payment">Payment</option>
                                    <option value="free">Free</option>
                                </select>
                            </p>

                            <p>Voucher date  : &nbsp;
                                <input type="date" min={"2022-01-01"} value={voucherDate} onChange={e => setVoucherDate(e.target.value)} />
                            </p>

                            {/* <button type="button">Submit</button> */}

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal" onClick={thisSubmit}>Submit</button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="text-center row">
                <div className="m-auto col-md-1">
                    <div className="text-center my-3">
                        <input type="text" placeholder="Search Name" onChange={e => setSearch(e.target.value)} />
                    </div>

                </div>

                <div className="col-md-2 my-2">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        Add New Voucher
                    </button>
                </div>
            </div>

            <Table />

        </>
    )
}


export default Home;