import { useContext } from "react";
import { Moweb } from "../App";

const Table = () => {
    const { data, duplicateData, deleteData } = useContext(Moweb)
    return (
        <>
            {
                data.length ?
                    <>
                        <table style={{ border: "1px solid black", margin: "auto" }}>
                            <tr className="text-center">
                                <td>id</td>
                                <td>image</td>
                                <td>name</td>
                                <td>DOB</td>
                                <td>number</td>
                                <td>Action</td>
                            </tr>

                            {
                                data.length && data.map((item, key) => {
                                    return (
                                        <>
                                            <tr>
                                                <td>{key + 1}</td>
                                                <td><img src={`http://localhost:4000/images/${item.image}`} class="rounded float-left" alt="Waiting..." height="40px" width="60px" /></td>
                                                <td>{item.name}</td>
                                                <td>{item.dob}</td>
                                                <td>{item.phoneNumber}</td>
                                                <td><button onClick={() => duplicateData(item)}>Duplicate</button> <button onClick={() => deleteData(item._id)}>Delete</button></td>
                                            </tr>
                                        </>
                                    )
                                })
                            }
                        </table>

                    </> :
                    <div className="text-center">
                        No data found
                    </div>
            }
        </>
    )
}

export default Table;