import { useContext } from "react";
import { Moweb } from "../App";

const Message = () => {
    const { dataMsgs } = useContext(Moweb)
    return (
        <>
            {
                dataMsgs ?
                    <>
                        {
                            dataMsgs.success ?
                                <div class="alert alert-success text-center" role="alert">
                                    {dataMsgs.success}
                                </div> :
                                <div class="alert alert-danger text-center" role="alert">
                                    {dataMsgs.error}
                                </div>
                        }
                    </> : ''
            }

        </>
    )

}

export default Message;