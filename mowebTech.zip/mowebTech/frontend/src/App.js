import React, { createContext, useState } from 'react'
import Home from "./components/Home";
import axios from 'axios';

export const Moweb = createContext();
function App() {

  const [dataMsgs, setDataMsgs] = useState(null);
  const [data, setData] = useState([]);


  const getData = async () => {
    console.log("starts")
    await axios.post('http://localhost:4000/getData')
      .then("sent")
      .then(res => {
        if (res.data.error) {
          alert(res.data.error)
        }
        setData(res.data)
      })
  }

  const submitData = async (photo, name, dob, number, voucherType, voucherDate) => {

    const formData = new FormData();
    formData.append('file', photo);
    formData.append('name', name);
    formData.append('dob', dob);
    formData.append('phoneNumber', number);
    formData.append('voucherType', voucherType);
    formData.append('voucherDate', voucherDate);

    await axios.post('http://localhost:4000/insertData', formData)
      .then(res => {
        console.log("res is : ", res.data)
        // if (res.data.error) {
        //     alert(res.data.error);
        // }
        setDataMsgs(res.data);
        // clearStates();
        getData();
        setTimeout(() => {
          setDataMsgs(null)
        }, 3000)
      })
  }

  const duplicateData = async (item) => {
    console.log("copy : ", item)
    await axios.post('http://localhost:4000/duplicateData', item)
      .then(res => {
        setDataMsgs(res.data);
        getData();
        setTimeout(()=>{
          setDataMsgs(null);
        },3000);
      })

  }


  const deleteData = async (id) => {
    await axios.post('http://localhost:4000/deleteData', { id })
      .then(res => {
        setDataMsgs(res.data);
        getData();
        setTimeout(()=>{
          setDataMsgs(null);
        },3000);
      })
  }

  const getSearchData = async (search) => {
    console.log("called ")
    await axios.post('http://localhost:4000/searchData', { input: search })
      .then(res => {
        if (res.data.error) {
          setDataMsgs(res.data.error);
        }
        setData(res.data)
      })
  }




  return (
    <div className="App">
      <div>
        <Moweb.Provider value={{ duplicateData, deleteData, dataMsgs, submitData, data, setData, getSearchData, getData }}>
          <Home />
        </Moweb.Provider>
      </div>
    </div>
  );
}

export default App;
